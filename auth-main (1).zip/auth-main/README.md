Note: user authentication using google doesnot work in deployed application, cuz its not linked to a doamain name.
to check one must run this in their respective locahost: --

# auth
This constais the basic user authorization that any application would required;
Sign up page, log in page, landing page;
creating user session, cookies, logging out;
user authentication using google;
encrypt-decrypt user passwords; 

